from setuptools import setup

setup(name='image_features_extraction',
      version='0.1',
      description='',
      url='http://github.com/rempic/bioimage_feature_extraction',
      author='',
      author_email='',
      license='',
      packages=['image_features_extraction'],
      zip_safe=False)
