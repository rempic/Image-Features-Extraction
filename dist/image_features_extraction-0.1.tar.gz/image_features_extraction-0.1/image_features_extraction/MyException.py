class MyException(Exception):
    pass
